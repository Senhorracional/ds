import java.util.Scanner;

public class nota {
    /**
     * @param args
     */
    
     public static void main(String[] args) {
        System.out.println("Digite a sua nota: ");
        @SuppressWarnings("resource")
        Scanner sc = new Scanner (System.in); 
        String nota  = sc.nextLine();   //Lê uma linha inteira do input como string

        switch (nota) {
            case "MB":
                System.out.println("Muito Bom!");
                break;
            case "B":
                System.out.println("Bom!");
                break;
            case "R":
                System.out.println("Regular");
                break;
            case "I":
                System.out.println("Irregular" + "\nVocê foi reprovado.");
                break;
            default:
            System.out.println("Nota Inválida." + "\nPor favor, digite apenas MB/B/R/I.");
                break;
        }
     }
}
