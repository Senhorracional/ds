import java.util.Scanner;

public class Genero{
    /**
     * @param args
     */
    
     public static void main(String[] args) {
        
        System.out.println("M ou F");
        @SuppressWarnings("resource")
        Scanner leitor = new Scanner (System.in); 
        char genero = leitor.next().charAt(0);   //pega a letra do que o usuario digitou
        switch (genero) {
            case 'M' | 'm':
                System.out.println("Você escolheu  Masculino!");
                break;
            case  'F' |  'f':
                System.out.println("Você escolheu Feminino!");
                break;
            default:
            System.out.println ("Valor inválido");
                break;
        }
     }
}