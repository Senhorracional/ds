import java.util.Scanner;

public class Canais {
    /**
     * @param args
     */
    
    public static void main(String[] args) {
        
        System.out.println("""
                           Escolha um canal:
                           2 - Cultura
                           4 - SBT
                           5 - Globo
                           7 - Record
                           9 - Manchete
                           13 - Bandeirante
                           21 - MTV""");
        @SuppressWarnings("resource")
        Scanner leitor = new Scanner(System.in);
        int num = leitor.nextInt();
        switch (num) {
            case 2:
                System.out.println("Você escolheu a Cultura!");
                break;
            case 4:
            System.out.println("Você escolheu o SBT!");
                break;
            case 5:  
                System.out.println("Você escolheuc a Globo! ");
                break;
            case 7: 
                System.out.println("Você escolheu o Record!");
                break;
            case 9: 
                System.out.println("Você escolheu a Manchete!");
                break;
            case  13: 
                System.out.println("Você escolheu a Bandeirante!");
                break;
            case  21: 
                System.out.println( "Você escolheu a MTV!");
                break;
            default:
                System.out.println("Canal não encntrado!");
                System.exit(0); //encerra o programa se o número for diferente dos acima
                break;
        }
    }
}