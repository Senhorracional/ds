/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nota;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class Nota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nota =  JOptionPane.showInputDialog("Insira a menção do aluno:");
        if (nota.equals("A") || nota.equals("B") || nota.equals("C")){
            JOptionPane.showMessageDialog(null, "Promovido");
            System.exit(0);
        }
        else if(nota.equals("D") ||  nota.equals("E")){
            JOptionPane.showMessageDialog(null, "Retido");
            System.exit(0);
        }
        else{
            JOptionPane.showMessageDialog(null, "Avaliação Inválida");
            System.exit(0);
        }

    }
    
}
