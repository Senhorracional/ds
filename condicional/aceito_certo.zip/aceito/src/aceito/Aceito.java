/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aceito;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class Aceito {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String sexo = JOptionPane.showInputDialog(null, "Masculino (M) e Feminino (F):");
        String altura = JOptionPane.showInputDialog(null, "Digite a sua altura:");
        String peso = JOptionPane.showInputDialog(null, "Digite o seu peso:");
        double altura1 = Double.parseDouble(altura);
        double peso1 = Double.parseDouble(peso);

        if(sexo.equals("M") && altura1 >= 1.80 && peso1 >= 75.0){
            JOptionPane.showMessageDialog(null, "Aceito");
            System.exit(0);
        }else{
            JOptionPane.showMessageDialog(null, "Não Aceito");
            System.exit(0);
        }
    }
    
}
