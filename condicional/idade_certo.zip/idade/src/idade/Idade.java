/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package idade;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno CA
 */
public class Idade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int num;
        String idade = JOptionPane.showInputDialog(null, "Digite a sua idade:");
        num = Integer.parseInt(idade);

        if(num < 18){
            JOptionPane.showMessageDialog(null, "Não Permitido");;
        }else{
          JOptionPane.showMessageDialog(null, "Permitido");
        }
    }
    
}
